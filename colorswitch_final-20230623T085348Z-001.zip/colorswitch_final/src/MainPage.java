import com.sun.javafx.iio.ios.IosDescriptor;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

import java.io.IOException;

public class MainPage {

    @FXML
    private AnchorPane enterName;

    @FXML
    private AnchorPane mainPage;

    static Stage stageM;

    @FXML
    private Button back , startBtn, help, hScrBtn,loadBtn, exBtn, jmp,nxtBtn;

    public void startGame(ActionEvent event) throws IOException {
//        Parent root = FXMLLoader.load(getClass().getResource("enterName.fxml"));
//        Stage newGameStage = new Stage();
////        newGameStage.setTitle("Level 1");
//        newGameStage.setScene(new Scene(root, 800, 450));
//        newGameStage.show();

//        Scene scene = new Scene(mainPage.getParent(),800,450);
//
//        back.setOnAction(e -> newGameStage.setScene(scene));
//        mainPage.getParent();


        Parent root;



        if(event.getSource()==startBtn){
            stageM = (Stage) startBtn.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("enterName.fxml"));
        }

        else if(event.getSource()==nxtBtn){
            stageM = (Stage) nxtBtn.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("Game.fxml"));
        }

        else{
            stageM = (Stage) back.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("mainPage.fxml"));
        }
        Scene scene = new Scene(root);
        stageM.setScene(scene);
        stageM.show();

    }

    public void help(ActionEvent event) throws IOException{
        Stage stage;
        Parent root;

        if(event.getSource()==help){
            stage = (Stage) help.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("Help.fxml"));
        }
        else{
            stage = (Stage) back.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("mainPage.fxml"));
        }


        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void loadGame(ActionEvent event) throws IOException{
        Stage stage;
        Parent root;

        if(event.getSource()==loadBtn){
            stage = (Stage) loadBtn.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("loadGame.fxml"));
        }
        else{
            stage = (Stage) back.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("mainPage.fxml"));
        }
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void highScore(ActionEvent event) throws IOException{
        Stage stage;
        Parent root;

        if(event.getSource()==hScrBtn){
            stage = (Stage) hScrBtn.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("highScore.fxml"));
        }
        else{
            stage = (Stage) back.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("mainPage.fxml"));
        }
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void exitGame(){
        System.exit(0);
    }


}
