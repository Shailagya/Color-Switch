import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.ListView;
import javafx.scene.layout.AnchorPane;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.URL;
import java.util.ResourceBundle;



public class LoadGame implements Initializable {

    @FXML
     public AnchorPane loadpane;
    @FXML
    public ListView loadTab;
    public void choose() throws IOException, ClassNotFoundException {
        int sl=loadTab.getSelectionModel().getSelectedIndex();
        FXMLLoader Game = new FXMLLoader(getClass().getResource("Game.fxml"));
        AnchorPane pane1 = Game.load();
        Game Good = Game.getController();
        loadpane.getChildren().setAll(pane1);
       //  Good.unjam(sl);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

//        File file = new File("Gamer.txt");
//
//        GamerTable gdt;
//        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("Gamer.txt"))) {
//            gdt = (GamerTable) in.readObject();
//            for (int i = 0; i < gdt.table.size(); i++) {
//                loadTab.getItems().add((i + 1) );
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//        } catch (ClassNotFoundException e) {
//            e.printStackTrace();
//        }

    }

}
