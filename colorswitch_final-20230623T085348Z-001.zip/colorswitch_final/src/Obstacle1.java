

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.RotateTransition;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.util.Duration;


import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class Obstacle1  {
    protected int Xaxis;
    protected int Yaxis;
    protected int size;
    protected int speed;
    protected String shape;
    protected double position;
    @FXML
    public Line Lblue,Lyell,Lpink,Lpurple;

    @FXML
    public AnchorPane containerOfSquare;

    @FXML
    private Rectangle rec1;

    @FXML
    private Button o1btn;

    private Ball Gend;



//    public void obst1() throws IOException {
//////        RotateTransition rotate = new RotateTransition(Duration.millis(300), rec1);
////
//        Rotate rotate = new Rotate();
//        Stage stage = new Stage();
//        Parent root;
//
////        root = FXMLLoader.load(getClass().getResource("Obstacle.fxml"));
////
////        rotate.setByAngle(360);
////        rotate.setCycleCount(2);
////        rotate.play();
////
//        rotate.setAngle(360);
//        rotate.setPivotX(100);
//        rotate.setPivotY(300);
//
////
//        containerOfSquare.getTransforms().add(rotate);
////
////        Scene scene = new Scene(root);
////        stage.setScene(scene);
////        stage.show();
//    }


    public void setXaxis(int Xaxis) {

    }

    public void setYaxis(int Yaxis) {

    }

    public int getSize() {
        return size;
    }

    public int getSpeed() {
        return speed;
    }

    public void setPos(double setPos) {

    }

    public double getPos() {
        return position;
    }

    public void move() {

    }

    @FXML
    public void initialize() {
        /*LRed.setLayoutY(100);
        Lpink.setLayoutY(100);
        Lblue.setLayoutY(100);
        Lyell.setLayoutY(100);
*/
        Rotate rotate1= new Rotate();
        Rotate rotate2= new Rotate();
        Rotate rotate3= new Rotate();
        Rotate rotate4= new Rotate();

        // Rotate rotate2


        rotate1.setAngle(360);
        rotate1.setAxis(Rotate.Z_AXIS);

        rotate1.setPivotX(101);
        rotate1.setPivotY(101);


        containerOfSquare.getTransforms().add(rotate1);




/*

        RotateTransition rotateTransition=new RotateTransition();
        rotateTransition.setAxis(Rotate.Z_AXIS);
        rotateTransition.setByAngle(360);
        rotateTransition.setCycleCount(200);
        rotateTransition.setDuration(Duration.millis(   200));
        rotateTransition.setNode(containerOfSquare);
        rotateTransition.play();
*/
    Timeline timeline = new Timeline(
                            new KeyFrame(Duration.ZERO, new KeyValue(rotate1.angleProperty(), 0)),
                new KeyFrame(Duration.seconds(1000), new KeyValue(rotate1.angleProperty(), 36000)));
      timeline.play();


        /*RotateTransition rotateTransition=new RotateTransition();
        rotateTransition.setAxis(Rotate.Z_AXIS);
        rotateTransition.setByAngle(360);
        rotateTransition.setCycleCount(500);
        rotateTransition.setDuration(Duration.millis(1200));
        rotateTransition.setNode(rec1);
        rotateTransition.play();

        Stage stage = new Stage();
        Parent root;
        try {
            root = FXMLLoader.load(getClass().getResource("Obstacle.fxml"));
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }*/

    }

//    public boolean Collision(){
//        return Gend.ball.getBoundsInParent().intersects(containerOfSquare.localToParent(Lyell.getBoundsInParent()));
////       return Shape.intersect(Gend.ball, Lyell).getBoundsInLocal().getWidth() != -1;
//    }
}
