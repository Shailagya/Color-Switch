
import java.util.ArrayList;

public class CurrentGame implements java.io.Serializable {
//    private int score;
//    //    private static ArrayList<Integer> score ;
//    private static ArrayList<Ball> ballPos;
//    private static ArrayList<Obstacle> obstacle;
//
//    public void resumeGame(){}
//
//    public void saveGame(){
//
//    }
//
//    public void restart(){}
//
//    public void setScore(int score){}
//
//    public int getScore(){
//        return score;
//    }
//
//    public ArrayList<Ball> getBallPos(){
//        return ballPos;
//    }
//
//    public ArrayList<Obstacle> getObstacle(){
//        return obstacle;
//    }
//
//    public void exist(){}


        ArrayList<Integer> RecentScore;

        double score;

        // y coordinates of make rectangle obj class
        double Rleftobs_yaxis;
        double Rrightobs_yaxis;

        // y coordinates  makeCircleobs
        double cir1_yaxis;
        double cir2_yaxis;

        //y coordinates of line obj
        double lineGroup_yaxis;

        // y coordinates of Ball
        double BallCenter_yaxis;

        // y axis of makeRotate Rectangle;
        double RRleftobs_yaxis;
        double RRrightobs_yaxis;

        // y axis of SimpleCircle

        double Simple_Cir1_yaxis;

        // y axis of Simple Rectangle
        double Simple_rightobs_yaxis;

        // y axis of Color Switcher;

        public double getStar_yaxis() {
            return star_yaxis;
        }

        public void setStar_yaxis(double star_yaxis) {
            this.star_yaxis = star_yaxis;
        }

        double colorSwitcher_yaxis;

        //yaxis of Star;

        double star_yaxis;


        public void setScore(double score) {
            this.score = score;
        }

        public void setRleftobs_yaxis(double rleftobs_yaxis) {
            Rleftobs_yaxis = rleftobs_yaxis;
        }

        public void setRrightobs_yaxis(double rrightobs_yaxis) {
            Rrightobs_yaxis = rrightobs_yaxis;
        }

        public void setCir1_yaxis(double cir1_yaxis) {
            this.cir1_yaxis = cir1_yaxis;
        }

        public void setCir2_yaxis(double cir2_yaxis) {
            this.cir2_yaxis = cir2_yaxis;
        }


        public void setBallCenter_yaxis(double ballCenter_yaxis) {
            BallCenter_yaxis = ballCenter_yaxis;
        }

        public void setRRleftobs_yaxis(double RRleftobs_yaxis) {
            this.RRleftobs_yaxis = RRleftobs_yaxis;
        }

        public void setRRrightobs_yaxis(double RRrightobs_yaxis) {
            this.RRrightobs_yaxis = RRrightobs_yaxis;
        }

        public void setSimple_Cir1_yaxis(double simple_Cir1_yaxis) {
            Simple_Cir1_yaxis = simple_Cir1_yaxis;
        }

        public void setSimple_rightobs_yaxis(double simple_rightobs_yaxis) {
            Simple_rightobs_yaxis = simple_rightobs_yaxis;
        }

        public void setColorSwitcher_yaxis(double colorSwitcher_yaxis) {
            this.colorSwitcher_yaxis = colorSwitcher_yaxis;
        }

        public double getScore() {
            return score;
        }

        public double getRleftobs_yaxis() {
            return Rleftobs_yaxis;
        }

        public double getRrightobs_yaxis() {
            return Rrightobs_yaxis;
        }

        public double getCir1_yaxis() {
            return cir1_yaxis;
        }

        public double getCir2_yaxis() {
            return cir2_yaxis;
        }

        public double getLineGroup_yaxis() {
            return lineGroup_yaxis;
        }

        public void setLineGroup_yaxis(double lineGroup_yaxis) {
            this.lineGroup_yaxis = lineGroup_yaxis;
        }

        public double getBallCenter_yaxis() {
            return BallCenter_yaxis;
        }

        public double getRRleftobs_yaxis() {
            return RRleftobs_yaxis;
        }

        public double getRRrightobs_yaxis() {
            return RRrightobs_yaxis;
        }

        public double getSimple_Cir1_yaxis() {
            return Simple_Cir1_yaxis;
        }

        public double getSimple_rightobs_yaxis() {
            return Simple_rightobs_yaxis;
        }

        public double getColorSwitcher_yaxis() {
            return colorSwitcher_yaxis;
        }



}
