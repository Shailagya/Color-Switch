import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.awt.*;
import java.io.IOException;

public class PauseGame {


     @FXML
      public AnchorPane lodumalik;

    @FXML
    public Button resumeBtn,menuBtn, restartBtn,savebutton;

    public void pauseGame(ActionEvent event) throws IOException, ClassNotFoundException {
        Stage stage;
        Parent root;
        if(event.getSource()==savebutton)
        {
            AnchorPane menu = FXMLLoader.load(getClass().getResource("mainPage.fxml"));
            lodumalik.getChildren().setAll(menu);
        }



        if(event.getSource()==resumeBtn){
            FXMLLoader game = new FXMLLoader(getClass().getResource("Game.fxml"));
            AnchorPane setGame = game.load();
            Game GR = game.getController();
            lodumalik.getChildren().setAll(setGame);
           // GR.unjam(-1);


             }



        if(event.getSource()==menuBtn){
            FXMLLoader gameRound = new FXMLLoader(getClass().getResource("Game.fxml"));
            AnchorPane setGame = gameRound.load();
            Game GR = gameRound.getController();
           // GR.unjam(-1);

            AnchorPane menu = FXMLLoader.load(getClass().getResource("mainPage.fxml"));
            lodumalik.getChildren().setAll(menu);
//
//            stage = (Stage) menuBtn.getScene().getWindow();
//
//            root = FXMLLoader.load(getClass().getResource("mainPage.fxml"));
//        }

    }

}
}
