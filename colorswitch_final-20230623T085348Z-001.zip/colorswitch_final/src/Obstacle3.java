import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Line;
import javafx.scene.transform.Rotate;
import javafx.util.Duration;

public class Obstacle3 {
    @FXML
    public Line Lpurple,Lyell,Lpink,Lblue;

    @FXML
    public AnchorPane containerOfCross;

    @FXML
    public void initialize() {

        Rotate rotate1= new Rotate();
        Rotate rotate2= new Rotate();
        Rotate rotate3= new Rotate();
        Rotate rotate4= new Rotate();

        rotate3.setAngle(360);
        rotate3.setAxis(Rotate.Z_AXIS);

        rotate3.setPivotX(150);
        rotate3.setPivotY(150);
        rotate3.setPivotZ(150);

        containerOfCross.getTransforms().add(rotate3);

        Timeline timeline = new Timeline(
                new KeyFrame(Duration.ZERO, new KeyValue(rotate3.angleProperty(), 0)),
                new KeyFrame(Duration.seconds(1000), new KeyValue(rotate3.angleProperty(), 36000)));
        timeline.play();

    }
}
