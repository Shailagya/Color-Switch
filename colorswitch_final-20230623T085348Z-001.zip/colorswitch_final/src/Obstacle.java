import java.util.ArrayList;

public class Obstacle {
    private ArrayList<Integer> Scorelist = new ArrayList<Integer>();


}
