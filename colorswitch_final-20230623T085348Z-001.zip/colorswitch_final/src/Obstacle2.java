import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Line;
import javafx.scene.transform.Rotate;
import javafx.util.Duration;

public class Obstacle2 {
    @FXML
    public Line Lred2,Lyell2,Lblue2;

    @FXML
    public AnchorPane containerOfTriangle;

    @FXML
    public void initialize() {

        Rotate rotate1= new Rotate();
        Rotate rotate2= new Rotate();
        Rotate rotate3= new Rotate();
        Rotate rotate4= new Rotate();

        rotate2.setAngle(360);
        rotate2.setAxis(Rotate.Z_AXIS);

        rotate2.setPivotX(180);
        rotate2.setPivotY(180);
        rotate2.setPivotZ(180);

        containerOfTriangle.getTransforms().add(rotate2);

        Timeline timeline = new Timeline(
                new KeyFrame(Duration.ZERO, new KeyValue(rotate2.angleProperty(), 0)),
                new KeyFrame(Duration.seconds(1000), new KeyValue(rotate2.angleProperty(), 36000)));
        timeline.play();



    }
}
