import com.sun.javafx.geom.Point2D;
import com.sun.javafx.iio.ios.IosDescriptor;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Bounds;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;



public class Ball   {


    @FXML
    public Button jmp;

    @FXML
    private Line line;

    @FXML
    public Circle ball;

    @FXML
    public Rectangle rect,base;


    public static Bounds bound;


    //    private Star starCount;
    private int size;
    private int speed;
    private String color;
    private int Xaxis;
    private int Yaxis;
    private int bounceHeight;
    private double position;
    private ArrayList<Obstacle1> obstaclePos;

//    @Override
//    public void start(Stage primaryStage) throws Exception{
//        Parent root = FXMLLoader.load(getClass().getResource("Game.fxml"));
//        Stage newGameStage = new Stage();
//        Scene scene = new Scene(root,800,450);
//        newGameStage.setScene(scene);
//        newGameStage.show();
//    }

//    public void display(ActionEvent event) throws IOException{
////        Stage stage;
////        Parent root;
////
////        if(event.getSource()==hScrBtn){
////            stage = (Stage) hScrBtn.getScene().getWindow();
////            root = FXMLLoader.load(getClass().getResource("highScore.fxml"));
////        }
////        else{
////            stage = (Stage) back.getScene().getWindow();
////            root = FXMLLoader.load(getClass().getResource("mainPage.fxml"));
////        }
////        Scene scene = new Scene(root);
////        stage.setScene(scene);
////        stage.show();
//
//        Parent root = FXMLLoader.load(getClass().getResource("Game.fxml"));
//        Stage newGameStage = new Stage();
//        Scene scene = new Scene(root,800,450);
//        newGameStage.setScene(scene);
//
//        scene.setOnKeyPressed(new EventHandler<KeyEvent>() {
//            @Override
//            public void handle(KeyEvent event) {
//                if(event.getCode().equals(KeyCode.SPACE))
//                    ball.setLayoutY(Ball.getLayoutY() - 100);
////                    ball;
//
//                Timeline t1 = new Timeline(new KeyFrame(Duration.millis(1100),
//                        new KeyValue(Ball.layoutYProperty(),200)));
//
//                t1.setCycleCount(1);
//                t1.play();
//
//            }
//        });
//
//        newGameStage.show();
//    }

//    public void setXaxis(int Xaxis){}
//
//    public void setYaxis(int Yaxis){}
//
//    public int getSize(){
//        return size;
//    }
//
//    public void setColor(String color){}
//
//    public String getColor(){
//        return color;
//    }
//
//    public int getSpeed(){
//        return speed;
//    }
//
//    public void setH(int bounceHeight){}
//
//    public int getH(){
//        return bounceHeight;
//    }
//
//    public void setPos(double position){}
//
//    public double getPos(){
//        return position;
//    }

    private double dist;

    public void bounceBall(ActionEvent event) throws IOException {

    //    jmp.setOnKeyPressed(new EventHandler<KeyEvent>() {
      //      @Override
          //  public void handle(KeyEvent event) {
          //      if (event.getCode() == KeyCode.SPACE) {
                    Timeline t1 = new Timeline(new KeyFrame(Duration.millis(200),new KeyValue(ball.layoutYProperty(),ball.getLayoutY() - 100)));
//        ball.setLayoutY(ball.getLayoutY() - 100);

                    t1.setCycleCount(1);
                    Timeline t2 = new Timeline(new KeyFrame(Duration.millis(1100),
                            new KeyValue(ball.layoutYProperty(),637)));

                    t2.setCycleCount(1);
                    t1.play();
                    t1.setOnFinished(actionEvent -> t2.play());
                }
   //         }
  //      });
//        gameOver();

//        System.out.println(ball.getRadius());
//        System.out.println(ball.getLayoutX());
//        System.out.println(ball.getLayoutBounds());
//        System.out.println(line.getLayoutBounds());
//        System.out.println(line.getBaselineOffset());
//        System.out.println(line.getLayoutX());
//        dist =
  //  }


    public void actionPerformed(java.awt.event.ActionEvent actionEvent) {
        bound = ball.getBoundsInLocal();
    }


//    public void gameOver(){
////        System.out.println(ball.getRadius());
////        System.out.println(line.getLayoutBounds());
//
//        if((rect.getBoundsInParent().intersects(ball.getBoundsInParent())))
//        {
//            System.out.println("Helloooo");
////            gameOver=true;
//            if(ball.getCenterX()<=rect.getX())
//                ball.setCenterX(rect.getX()-2*ball.getRadius()+10);
//            else
//            {
//                if(rect.getY()!=0)
//                {
//                    ball.setCenterY(rect.getY()-2*ball.getRadius());
//                }
//                else if(ball.getCenterY()>rect.getHeight()){
//                    ball.setCenterY(rect.getHeight());
//                }
//            }
//        }
//
//        else{
//            System.out.println("Morniggg");
//        }
////        if(ball.getCenterY()>H-120||ball.getCenterY()<0)
////        {
////            gameOver=true;
////
////        }
//
//
//    }

//    void Collision(){
//        for(Rectangle column:columns)
//        {
//            if((column.getBoundsInParent().intersects(bird.getBoundsInParent())))
//            {
//                gameOver=true;
//                if(bird.getCenterX()<=column.getX())
//                    bird.setCenterX(column.getX()-2*bird.getRadiusX()+10);
//                else
//                {
//                    if(column.getY()!=0)
//                    {
//                        bird.setCenterY(column.getY()-2*bird.getRadiusY());
//                    }
//                    else if(bird.getCenterY()>column.getHeight()){
//                        bird.setCenterY(column.getHeight());
//                    }
//                }
//            }
//
//
//        }
//        if(bird.getCenterY()>H-120||bird.getCenterY()<0)
//        {
//            gameOver=true;
//
//        }
//
//        if(gameOver)
//        {
//            bird.setCenterY(H-120-bird.getRadiusY());
//            l.setText("GameOver\n   Score:"+str.toString(score/2));
//            l.setFont(new Font("Arial",50));
//            l.setLayoutX(primaryStage.getWidth()/2-130);
//            l.setLayoutY(primaryStage.getHeight()/2-50);
//            l.setTextFill(Color.ORANGE);
//
//
//        }
//    }

}
