import javafx.animation.*;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Shape;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.*;
import java.util.ArrayList;
import java.util.Random;

public class Game implements Serializable{
    private Star ss;

    private Ball Gend;
    private Obstacle1 obst1;
    private Obstacle2 obst2;
    private Obstacle3 obst3;
    private Obstacle4 obst4;
    private GameOver GOver;

    private int Points;
    private int finalflag2 =1;

//    private int Obstflag1=1;

    static Label abc,abc1,abc2;
    AnimationTimer timer;


//    private int flag=0;
//    private int flag2=0;




    double t=0;
    private AnchorPane Pane1,Pane2,Pane3,Pane4,Pane5,Pane6,Pane7;

    @FXML
    private AnchorPane GamePane;

    @FXML
    private AnchorPane containerOfSquare;

    @FXML
    private Button pauseBtn;

    @FXML
    private Label Score;

//    private Hit hit;

    Color pink = Color.rgb(252,34,131);
    Color blue = Color.rgb(44,208,245);
    Color purple = Color.rgb(150,45,252);
    Color yellow = Color.rgb(255,216,8);
//    Color red = Color.rgb(255,4,4);

    @FXML
    public void pause(ActionEvent event) throws IOException {
        Stage stageN;
        Parent rootN;

        if(event.getSource()==pauseBtn){
            stageN = (Stage) pauseBtn.getScene().getWindow();
            rootN = FXMLLoader.load(getClass().getResource("PausePage.fxml"));
            Scene sceneN = new Scene(rootN);
            stageN.setScene(sceneN);
            stageN.show();
        }
    }

    @FXML
    public void gameOver(ActionEvent event) throws IOException{

    }


    @FXML
    public void initialize() throws IOException {


        FXMLLoader load1 = new FXMLLoader(getClass().getResource("Ball.FXML"));
        Pane1 = load1.load();
        Gend = load1.getController();
//        Gend.jmp.setDefaultButton(true);
        GamePane.getChildren().add(Pane1);

        FXMLLoader load2 = new FXMLLoader(getClass().getResource("Star.FXML"));
        Pane2 = load2.load();
        ss=load2.getController();
        GamePane.getChildren().add(Pane2);


        FXMLLoader load3 = new FXMLLoader(getClass().getResource("Obstacle.FXML"));
        Pane3 = load3.load();
        obst1=load3.getController();
        GamePane.getChildren().add(Pane3);

       FXMLLoader load4 = new FXMLLoader(getClass().getResource("Obst2.FXML"));
        Pane4 = load4.load();
        obst2=load4.getController();
        GamePane.getChildren().add(Pane4);

        FXMLLoader load5 = new FXMLLoader(getClass().getResource("obst3.FXML"));
        Pane5 = load5.load();
        obst3=load5.getController();
        GamePane.getChildren().add(Pane5);

        FXMLLoader load6 = new FXMLLoader(getClass().getResource("obst4.FXML"));
        Pane6 = load6.load();
        obst4=load6.getController();
        GamePane.getChildren().add(Pane6);




        obst4.containerOfCircle.setLayoutY(-2200);
        obst2.containerOfTriangle.setLayoutY(-1800);
        obst1.containerOfSquare.setLayoutY(-800);
        obst3.containerOfCross.setLayoutY(-200);

      //  pauseBtn.setOnAction(new EventHandler<ActionEvent>() {
        //   @Override
          //  public void handle(ActionEvent event) {
                /*Stage stage;
                Parent root;

                stage = (Stage) pauseBtn.getScene().getWindow();
                try {
                    root = FXMLLoader.load(getClass().getResource("PausePage.fxml"));
                    Scene scene = new Scene(root);
                    stage.setScene(scene);
                    stage.show();
                } catch (IOException e) {
                    e.printStackTrace();
                }*/

        //    }
      //  });

        Gend.ball.setFill(cSwitch());


         timer = new AnimationTimer() {
            @Override
            public void handle(long now) {
                try {
                    runner();
                } catch (IOException | ClassNotFoundException e) {
                    e.printStackTrace();
                }

            }
        };

        timer.start();





    }


    private void runner() throws IOException, ClassNotFoundException {
        t+=0.016;

        int flag=0;
        int obFlag1=0;
        int flag2=0;

//        int obstfla1=0;


        double pos= obst3.containerOfCross.getLayoutY();
        double pos2= obst1.containerOfSquare.getLayoutY();
        double pos3= obst2.containerOfTriangle.getLayoutY();
        double pos4=ss.star.getLayoutY();
        double pos5= ss.cSwitch.getLayoutY();
        double pos6= obst4.containerOfCircle.getLayoutY();


        if(pos4<=131)
        {
            ss.star.setLayoutY(++pos4);
        }
       // double pos4= Gend.base.getLayoutY();

        if(pos5<=-21){
            ss.cSwitch.setLayoutY(++pos5);
        }

        pos=pos+0.2;
        pos2 = pos2+0.2;
        pos3= pos3+0.2 ;
        pos6= pos6+0.2;


        if(pos>700){
            pos=-2000;
            //obst3.containerOfCross.setLayoutY(58);
        }
        obst3.containerOfCross.setLayoutY(pos);


        if(pos2>700){
            pos2=-2000;
            //obst3.containerOfCross.setLayoutY(58);
        }
        obst1.containerOfSquare.setLayoutY(pos2);


        if(pos3>700){
            pos3=-2000;
            //obst3.containerOfCross.setLayoutY(58);
        }
        obst2.containerOfTriangle.setLayoutY(pos3);

        if(pos6>700){
            pos6=-2000;
        }
        obst4.containerOfCircle.setLayoutY(pos6);

//        if(obst3.containerOfCross.getBoundsInParent().intersects(Gend.base.getBoundsInParent())){
//            obst1.containerOfSquare.setLayoutY(pos2);
//            if(Gend.ball.getBoundsInParent().intersects(ss.star.getBoundsInParent())){
//                System.out.println("heloooooo");
//                obst1.containerOfSquare.setLayoutY(pos2+0.2);
//            }
//        }



//        obst1.containerOfSquare.setLayoutY(pos2);

//        obst1.containerOfSquare.setLayoutY(pos2);
//
//        if(obst1.containerOfSquare.getBoundsInParent().intersects(Gend.base.getBoundsInParent())){
//            obst2.containerOfTriangle.setLayoutY(pos2);
//        }
//
//        obst2.containerOfTriangle.setLayoutY(pos2);
//
//        if(obst2.containerOfTriangle.getBoundsInParent().intersects(Gend.base.getBoundsInParent())){
//            obst3.containerOfCross.setLayoutY(pos+0.2);
//        }



//        if(pos>1200)
//        {
//            pos=-1200;
//            //obst3.containerOfCross.setLayoutY(58);
//        }
//        GamePane.setLayoutY(++pos);




//        obst2.containerOfTriangle.setLayoutY(pos3);

//        if(pos4>700)
//        {
//            pos4=-500000;
//            //obst3.containerOfCross.setLayoutY(58);
//        }
//        Gend.base.setLayoutY(++pos4);
//        Gend.ball.setFill(blue);
//        Gend.ball.setFill(red);
//        Gend.ball.setFill(purple);

//////////////////////////////////////////////////////////// Obst 1//////////////////////////////////////////////////////////////////////////
        if(Gend.ball.getFill()==yellow ){
            if(Shape.intersect(Gend.ball,obst1.Lblue).getBoundsInLocal().getWidth() != -1 || Shape.intersect(Gend.ball,obst1.Lpink).getBoundsInLocal().getWidth() != -1 || Shape.intersect(Gend.ball,obst1.Lpurple).getBoundsInLocal().getWidth() != -1){
                flag2=1;
            }
        }

        if(Gend.ball.getFill()==pink ){
            if(Shape.intersect(Gend.ball,obst1.Lblue).getBoundsInLocal().getWidth() != -1 || Shape.intersect(Gend.ball,obst1.Lyell).getBoundsInLocal().getWidth() != -1 || Shape.intersect(Gend.ball,obst1.Lpurple).getBoundsInLocal().getWidth() != -1){
                flag2=1;
            }
        }

        if(Gend.ball.getFill()==blue ){
            if(Shape.intersect(Gend.ball,obst1.Lyell).getBoundsInLocal().getWidth() != -1 || Shape.intersect(Gend.ball,obst1.Lpink).getBoundsInLocal().getWidth() != -1 || Shape.intersect(Gend.ball,obst1.Lpurple).getBoundsInLocal().getWidth() != -1){
                flag2=1;
            }
        }

        if(Gend.ball.getFill()==purple ){
            if(Shape.intersect(Gend.ball,obst1.Lblue).getBoundsInLocal().getWidth() != -1 || Shape.intersect(Gend.ball,obst1.Lpink).getBoundsInLocal().getWidth() != -1 || Shape.intersect(Gend.ball,obst1.Lyell).getBoundsInLocal().getWidth() != -1){
                flag2=1;
            }
        }

        //////////////////////////////////////////// Obst 3 //////////////////////////////////////////////////////////////////////////////////////
        if(Gend.ball.getFill()==yellow ){
            if(Shape.intersect(Gend.ball,obst3.Lblue).getBoundsInLocal().getWidth() != -1 || Shape.intersect(Gend.ball,obst3.Lpink).getBoundsInLocal().getWidth() != -1 || Shape.intersect(Gend.ball,obst3.Lpurple).getBoundsInLocal().getWidth() != -1){
                flag2=1;
            }
        }

        if(Gend.ball.getFill()==pink ){
            if(Shape.intersect(Gend.ball,obst3.Lblue).getBoundsInLocal().getWidth() != -1 || Shape.intersect(Gend.ball,obst3.Lyell).getBoundsInLocal().getWidth() != -1 || Shape.intersect(Gend.ball,obst3.Lpurple).getBoundsInLocal().getWidth() != -1){
                flag2=1;
            }
        }

        if(Gend.ball.getFill()==blue ){
            if(Shape.intersect(Gend.ball,obst3.Lyell).getBoundsInLocal().getWidth() != -1 || Shape.intersect(Gend.ball,obst3.Lpink).getBoundsInLocal().getWidth() != -1 || Shape.intersect(Gend.ball,obst3.Lpurple).getBoundsInLocal().getWidth() != -1){
                flag2=1;
            }
        }

        if(Gend.ball.getFill()==purple ){
            if(Shape.intersect(Gend.ball,obst3.Lblue).getBoundsInLocal().getWidth() != -1 || Shape.intersect(Gend.ball,obst3.Lpink).getBoundsInLocal().getWidth() != -1 || Shape.intersect(Gend.ball,obst3.Lyell).getBoundsInLocal().getWidth() != -1){
                flag2=1;
            }
        }

        ////////////////////////////////////////////////////  obst 4////////////////////////////////////////////////////////////


        if(Gend.ball.getFill()==yellow ){
            if(Shape.intersect(Gend.ball,obst4.Lblue).getBoundsInLocal().getWidth() != -1 || Shape.intersect(Gend.ball,obst4.Lpink).getBoundsInLocal().getWidth() != -1 || Shape.intersect(Gend.ball,obst4.Lpurple).getBoundsInLocal().getWidth() != -1){
                flag2=1;
            }
        }

        if(Gend.ball.getFill()==pink ){
            if(Shape.intersect(Gend.ball,obst4.Lblue).getBoundsInLocal().getWidth() != -1 || Shape.intersect(Gend.ball,obst4.Lyell).getBoundsInLocal().getWidth() != -1 || Shape.intersect(Gend.ball,obst4.Lpurple).getBoundsInLocal().getWidth() != -1){
                flag2=1;
            }
        }

        if(Gend.ball.getFill()==blue ){
            if(Shape.intersect(Gend.ball,obst4.Lyell).getBoundsInLocal().getWidth() != -1 || Shape.intersect(Gend.ball,obst4.Lpink).getBoundsInLocal().getWidth() != -1 || Shape.intersect(Gend.ball,obst4.Lpurple).getBoundsInLocal().getWidth() != -1){
                flag2=1;
            }
        }

        if(Gend.ball.getFill()==purple ){
            if(Shape.intersect(Gend.ball,obst4.Lblue).getBoundsInLocal().getWidth() != -1 || Shape.intersect(Gend.ball,obst4.Lpink).getBoundsInLocal().getWidth() != -1 || Shape.intersect(Gend.ball,obst4.Lyell).getBoundsInLocal().getWidth() != -1){
                flag2=1;
            }
        }

        /////////////////////////////////////////// Obst 2////////////////////////////////////////////////////////////////////////////////////////





//
//        if(Gend.ball.getFill()==yellow ){
//            if(Shape.intersect(Gend.ball,obst2.Lblue2).getBoundsInLocal().getWidth() != -1 || Shape.intersect(Gend.ball,obst2.Lred2).getBoundsInLocal().getWidth() != -1){
//                System.out.println("Game Over 2 : Ball hit Anchor");
//                System.exit(5);
//            }
//        }


//        if(Gend.ball.getFill()==yellow ){
//            if(Shape.intersect(Gend.ball,obst3.Lblue).getBoundsInLocal().getWidth() != -1 || Shape.intersect(Gend.ball,obst3.Lpink).getBoundsInLocal().getWidth() != -1 || Shape.intersect(Gend.ball,obst3.Lpurple).getBoundsInLocal().getWidth() != -1){
//                System.out.println("Game Over 2 : Ball hit Anchor");
//                System.exit(5);
//            }
//        }




        if(Gend.ball.getBoundsInParent().intersects(ss.star.getBoundsInParent()))
        {
            Points=Points+1;
//            yourScore.setText(String.valueOf(Points));

            File file = new File("Stoat.txt");
            if(file.exists()){

            try{
                BufferedReader reader = new BufferedReader(new FileReader(file));
                String  str = reader.readLine();
                if(Integer.parseInt(str)<Points){
                    PrintWriter output = new PrintWriter(file);
                    output.println(Integer.toString(Points));
                    output.close();
                }
            }catch(FileNotFoundException ex){
//                System.out.println("ERROR: %s\n", ex);
        }

            }

            else{
                PrintWriter output = new PrintWriter(file);
                output.println(Integer.toString(0));
                output.close();
            }

            Score.setText(Points+"");
//            GOver.yourScore.setText(Points+"");
//            GameOver.yourScore.setText(Points+"");

            ss.star.setLayoutY(-2100);
            System.out.println("star is in collision");

          //  ss.star.setLayoutY(-700);

            //GamePane.getChildren().removeAll(Pane3);
        }




        if(Gend.ball.getBoundsInParent().intersects(ss.cSwitch.getBoundsInParent())){
            ss.cSwitch.setLayoutY(-2100);
            flag=1;
        }

        if(flag==1){
            Gend.ball.setFill(cSwitch());
        }

        if(Gend.ball.getBoundsInParent().intersects(Gend.base.getBoundsInParent())){
//            System.exit(7);
            flag2=1;


        }

        if(flag2==1 && finalflag2==1){
            timer.stop();


//            jam();
//            FXMLLoader loadBall = new FXMLLoader(getClass().getResource("GameOver.fxml"));
//            AnchorPane over = loadBall.load();
//            GameOver go = loadBall.getController();
            Stage stageN = new Stage();
            Parent rootN;
            System.out.println("Game Over");
            stageN = (Stage) pauseBtn.getScene().getWindow();
            rootN = FXMLLoader.load(getClass().getResource("GameOver.fxml"));
            Scene sceneN = new Scene(rootN);
            stageN.setScene(sceneN);
            stageN.show();


            abc= (Label)rootN.lookup("#bestScore");
            abc1= (Label)rootN.lookup("#yourScore");
//            abc2= (Label)rootN.lookup("#highScore");
            File file = new File("Stoat.txt");
            if(file.exists()){

                try{
                    BufferedReader reader = new BufferedReader(new FileReader(file));
                    String  str = reader.readLine();
                    System.out.println(str);
                    abc.setText(str+" ");
//                    go.yourScore.setText(Points+"");
//                    go.bestScore.setText(str+"");
//               /     AnchorPane over  = FXMLLoader.load(getClass().getResource("GameOver.fxml"));
//                    GamePane.getChildren().setAll(over);/

                    abc1.setText(Points+" ");
                    abc2.setText(str+" ");

      //             GameOver.bestScore.setText(str+"");

                }catch(FileNotFoundException ex){
//                System.out.println("ERROR: %s\n", ex);
                }

            }

            else{
//                PrintWriter output = new PrintWriter(file);
//                output.println(Integer.toString(0));
                System.out.println("0");
//                output.close();
            }

            finalflag2=0;
        //}






//        Gend.ball.setStroke(Color.rgb(44,208,245));

        if (t > 2) {
                t = 0;
            }
    }

}

//    private boolean ballSwitch(){
//        if(Gend.ball.getFill()==yellow ){
//            System.out.println("ball is of yellow");
//            if(Gend.ball.getBoundsInParent().intersects(obst1.Lyell.getBoundsInParent())){
//                 System.out.println("Game Over 2");
//                 return true;
//                System.exit(5);
//            }
//        }
//    }

    private Color cSwitch() {
//        System.out.println("in cballl");
        Color[] cobst1 = {blue, yellow, purple, pink};
        Random random1 = new Random();

        int select = random1.nextInt(cobst1.length);

//        System.out.println("Random String selected: " + cobst1[select]);

//        Timeline t1 = new Timeline(new KeyFrame(Duration.millis(2),new KeyValue(Gend.ball.fillProperty(),cobst1[select])));

//        t1.setCycleCount(5);
//        Timeline t2 = new Timeline(new KeyFrame(Duration.millis(1100),new KeyValue(ball.layoutYProperty(),630)));

//        t2.setCycleCount(1);
//        t1.play();
//        t1.setOnFinished(actionEvent -> t2.play());

        return cobst1[select];
    }



//    @FXML
//    private void pauseGame(ActionEvent event) throws IOException{
//        pauseBtn.setOnKeyPressed(new EventHandler<KeyEvent>() {
//
//            @Override
//            public void handle(KeyEvent event) {
//                if (event.getCode() == KeyCode.SHIFT) {
//                    System.out.println("Enter Pressed");
//
//                    try {
//                        Stage stage;
//                        Parent root;
//
//                        stage = (Stage) pauseBtn.getScene().getWindow();
//                        root = FXMLLoader.load(getClass().getResource("PausePage.fxml"));
//
//                        Scene scene = new Scene(root);
//                        stage.setScene(scene);
//                        stage.show();
//
//                    } catch (IOException e) {
//                        e.printStackTrace();
//                    }
//
//                }
//            }
//        });
//    }

}
