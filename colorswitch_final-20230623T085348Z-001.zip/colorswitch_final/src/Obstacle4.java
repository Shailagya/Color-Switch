import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.RotateTransition;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Arc;
import javafx.scene.shape.Line;
import javafx.scene.transform.Rotate;
import javafx.util.Duration;

public class Obstacle4 {
    @FXML
    public Arc Lpurple,Lyell,Lpink,Lblue;

    @FXML
    public AnchorPane containerOfCircle;

    @FXML
    public void initialize() {


        RotateTransition rotate4= new RotateTransition();

//        rotate4.setAngle(360);
        rotate4.setByAngle(360);
        rotate4.setAxis(Rotate.Z_AXIS);

        rotate4.setCycleCount(500);

        //Setting duration of the transition
        rotate4.setDuration(Duration.millis(1000));

        //the transition will be auto reversed by setting this to true
//        rotate4.setAutoReverse(true);

        //setting Rectangle as the node onto which the
// transition will be applied
        rotate4.setNode(containerOfCircle);

        //playing the transition
        rotate4.play();

//        rotate4.setPivotX(150);
//        rotate4.setPivotY(150);
//        rotate4.setPivotZ(150);



//        containerOfCircle.getTransforms().add(rotate4);

//        Timeline timeline = new Timeline(
//                new KeyFrame(Duration.ZERO, new KeyValue(rotate4. 0)),
//                new KeyFrame(Duration.seconds(1000), new KeyValue(rotate4.angleProperty(), 36000)));
//        timeline.play();

    }

}
