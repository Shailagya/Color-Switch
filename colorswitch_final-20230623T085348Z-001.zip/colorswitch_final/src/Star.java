import javafx.fxml.FXML;
import javafx.scene.ImageCursor;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Star {
    @FXML
    public ImageView star,cSwitch;

}
