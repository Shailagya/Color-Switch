
public class Player {
    private CurrentGame currentGame;
    private String Name;

    public void setName(String Name){

    }

    public String getName(){
        return Name;
    }

    public void newGame(){

    }

    public void loadGame(){

    }
}
