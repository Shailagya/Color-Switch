import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.*;

public class GameOver {
     public int hs;

    @FXML
    public static Label yourScore,bestScore;

    @FXML
    public Button exitBtn,menuBtn, restartBtn;
    public AnchorPane gameoverpane;

    public void gameOver(ActionEvent event)throws IOException,ClassNotFoundException {
       if (event.getSource()==menuBtn)

       {
           AnchorPane pane = FXMLLoader.load(getClass().getResource("mainPage.fxml"));
           gameoverpane.getChildren().setAll(pane);
           }
        if(event.getSource()==restartBtn){
//            ObjectInputStream listt = null;
//            GamerTable tab;
//            Gamer gg;
//            try{
//                listt = new ObjectInputStream(new FileInputStream("Gamer.txt"));
//                tab = (GamerTable) listt.readObject();
//
//            } finally {
//                listt.close();
//            }
//            gg = tab.table.get(tab.table.size() - 1);
//            tab.table.remove(gg);
//            try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("Gamer.txt"))) {
//                out.writeObject(tab);
//            }
            AnchorPane pane = FXMLLoader.load(getClass().getResource("Game.fxml"));
            gameoverpane.getChildren().setAll(pane);

        }

//        else if(event.getSource()==menuBtn){
//            stage = (Stage) menuBtn.getScene().getWindow();
//            root = FXMLLoader.load(getClass().getResource("mainPage.fxml"));
//        }

    }

    public void exitGame(){
        System.exit(0);
    }

}
